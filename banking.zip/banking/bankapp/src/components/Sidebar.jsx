import React from 'react';
import { FiHome, FiCreditCard, FiPieChart, FiSettings, FiUser, FiLogOut } from 'react-icons/fi';
import { Link, useLocation } from 'react-router-dom';
import '../../styles/sidebar.css';

const Sidebar = () => {
  const location = useLocation();
  const navItems = [
    { icon: <FiHome size={20} />, label: 'Dashboard', path: '/' },
    { icon: <FiCreditCard size={20} />, label: 'Cards', path: '/cards' },
    { icon: <FiPieChart size={20} />, label: 'Analytics', path: '/analytics' },
    { icon: <FiSettings size={20} />, label: 'Settings', path: '/settings' },
  ];

  return (
    <div className="sidebar">
      <Link to="/" className="sidebar-logo">
        <div className="logo-icon">B</div>
        <h1 className="logo-text">BankApp</h1>
      </Link>

      <nav className="nav-menu">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`nav-link ${location.pathname === item.path ? 'active' : ''}`}
          >
            {item.icon}
            <span className="nav-link-text">{item.label}</span>
          </Link>
        ))}
      </nav>

      <div className="sidebar-footer">
        <button className="sidebar-button" type="button">
          <FiUser size={20} />
          <span>Profile</span>
        </button>
        <button className="sidebar-button" type="button">
          <FiLogOut size={20} />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
