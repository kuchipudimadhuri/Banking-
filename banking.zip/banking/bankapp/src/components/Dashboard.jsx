import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { FiDollarSign, FiCreditCard, FiTrendingUp, FiSend, FiDownload, FiUpload, FiBell, FiUser } from 'react-icons/fi';
import '../styles/dashboard.css';

ChartJS.register(ArcElement, Tooltip, Legend);

const Dashboard = () => {
  const data = {
    labels: ['Shopping', 'Bills', 'Food', 'Transport', 'Entertainment', 'Others'],
    datasets: [
      {
        data: [30, 20, 15, 15, 10, 10],
        backgroundColor: [
          '#4F46E5',
          '#818CF8',
          '#C7D2FE',
          '#E0E7FF',
          '#A5B4FC',
          '#EDE9FE',
        ],
        borderWidth: 0,
      },
    ],
  };

  const transactions = [
    { id: 1, name: 'Grocery Store', date: 'Today', amount: '-$86.00', type: 'shopping' },
    { id: 2, name: 'Netflix Subscription', date: 'Yesterday', amount: '-$12.99', type: 'entertainment' },
    { id: 3, name: 'Salary Deposit', date: 'Aug 10', amount: '+$4,500.00', type: 'deposit' },
  ];

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <div className="dashboard-title">
          <h1>Dashboard</h1>
          <p>Welcome back, John!</p>
        </div>
        <div className="user-actions">
          <button className="icon-button">
            <FiBell className="icon" size={20} />
          </button>
          <div className="user-avatar">
            <span>JD</span>
          </div>
        </div>
      </div>

      <div className="cards-container">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Total Balance</h3>
            <div className="card-icon balance">
              <FiDollarSign size={20} />
            </div>
          </div>
          <h2 className="card-amount">$12,450.00</h2>
          <p className="card-change">+2.4% from last month</p>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Total Income</h3>
            <div className="card-icon income">
              <FiTrendingUp size={20} />
            </div>
          </div>
          <h2 className="card-amount">$8,450.00</h2>
          <p className="card-change">+1.2% from last month</p>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Total Expense</h3>
            <div className="card-icon expense">
              <FiCreditCard size={20} />
            </div>
          </div>
          <h2 className="card-amount">$4,000.00</h2>
          <p className="card-change">-0.8% from last month</p>
        </div>
      </div>

      <div className="dashboard-content">
        <div className="chart-container">
          <div className="chart-header">
            <h2>Expense Analysis</h2>
            <select className="chart-select">
              <option>This Week</option>
              <option>This Month</option>
              <option>This Year</option>
            </select>
          </div>
          <div className="chart-wrapper">
            <Doughnut data={data} options={{ cutout: '70%' }} />
          </div>
        </div>

        <div className="transactions-container">
          <div className="transactions-header">
            <h2>Recent Transactions</h2>
            <a href="#" className="view-all">View All</a>
          </div>
          <div className="transactions-list">
            {transactions.map((transaction) => (
              <div key={transaction.id} className="transaction-item">
                <div className="transaction-info">
                  <div className={`transaction-icon ${transaction.type}`}>
                    {transaction.type === 'deposit' ? <FiDownload size={20} /> : <FiUpload size={20} />}
                  </div>
                  <div className="transaction-details">
                    <h4>{transaction.name}</h4>
                    <p>{transaction.date}</p>
                  </div>
                </div>
                <span className={`transaction-amount ${transaction.type === 'deposit' ? 'positive' : 'negative'}`}>
                  {transaction.amount}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="quick-actions">
        <h2>Quick Actions</h2>
        <div className="actions-grid">
          <a href="#" className="action-button">
            <div className="action-icon">
              <FiSend size={20} />
            </div>
            <span className="action-label">Send Money</span>
          </a>
          <a href="#" className="action-button">
            <div className="action-icon">
              <FiDownload size={20} />
            </div>
            <span className="action-label">Request</span>
          </a>
          <a href="#" className="action-button">
            <div className="action-icon">
              <FiCreditCard size={20} />
            </div>
            <span className="action-label">Cards</span>
          </a>
          <a href="#" className="action-button">
            <div className="action-icon">
              <FiTrendingUp size={20} />
            </div>
            <span className="action-label">Invest</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
