import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';
import './styles/components.css';
import './styles/sidebar.css';
import './styles/dashboard.css';

function App() {
  return (
    <Router>
      <div className="app-container">
        <Sidebar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/cards" element={<div className="page-content">Cards Page</div>} />
            <Route path="/analytics" element={<div className="page-content">Analytics Page</div>} />
            <Route path="/settings" element={<div className="page-content">Settings Page</div>} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
